myApp.controller("bookAddController",function($scope,bookManage){
    $scope.saveDetailsEventHandler=function(){
        bookManage.addBook($scope.newBook)
    }
})




/* myApp.controller("empAddController",function($scope,empManage){
    $scope.saveDetailsEventHandler=function(){
        empManage.addEmployee($scope.newEmployee)
    }
}) */