myApp.controller("bookDisplayController",function($scope,bookManage){
   $scope.bookArr=bookManage.getAllBookDetails();
   $scope.showAddBook=false;
   $scope.showAddNewBookEventHandler=function(){
      $scope.showAddBook=true;
   }
   $scope.showEditBook=false;
   $scope.editBookDetailsEventHandler=function(book){
      $scope.selectedBook=book;
      alert("U have selected BookId :"+ book.bookId + " to edit");
      $scope.showEditBook=true;
   }
})