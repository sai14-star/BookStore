myApp.service("bookManage",function(){
    this.bookDetails=[
        {bookId:101,bookName:"TheSecretGarden",bookAuthor:"Sai",bookIsbnCode:"D1",bookDescription:"Happiness is equal to Unselfishness",bookPrice:"3000",bookUrl:'D:\\Images\\SecretGarden.jpeg'},
        {bookId:102,bookName:"OneDayLifeWillChange",bookAuthor:"Sanath",bookIsbnCode:"D1",bookDescription:"who seems intent on running away from love",bookPrice:"2000",bookUrl:'D:\\Images\\OneDayWillChange.jpg'},
        {bookId:103,bookName:"LearningHowToFly",bookAuthor:"Sharath",bookIsbnCode:"D2",bookDescription:" In each one of them he has spoken about preparing oneself best for life",bookPrice:"4000",bookUrl:'D:\\Images\\LearningHowToFly.jpg'},
        {bookId:104,bookName:"LifeIsWhatYouMakeIt",bookAuthor:"Shyam",bookIsbnCode:"D1",bookDescription:"The book is based on a true story and when I first heard the story",bookPrice:"5000",bookUrl:'D:\\Images\\LifeIsWhatYouMakeIt.jpg'}]
    this.getAllBookDetails=function()
    {
        return this.bookDetails;
    }
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }
    
    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    } 
})