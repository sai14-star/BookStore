myApp.controller("bookSearchController",function($scope,bookManage){
    $scope.bookSearchArr=bookManage.getAllBookDetails();
    $scope.deleteBookEventHandler=function(bookToBeDeleted)
    {
        bookManage.deleteBook(bookToBeDeleted);
       /*   this.deleteBook=function(book){
            var pos=bookSearchArr.findIndex(item=> {
                if(item.bookId == book.bookId)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            })
            this.bookDetails.splice(pos,1);
     */
         
        
    }
})