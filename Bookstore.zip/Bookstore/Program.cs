﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore
{
    class Books
    {
        public int Id;
        public string bookName, authorName, descriptionOfBook;
        public double  price;
        public Books()
        {

        }
        public Books(int id, string bookName, string authorName, string descriptionOfBook,double price)
        {
            this.Id = id;
            this.bookName = bookName;
            this.authorName = authorName;
            this.descriptionOfBook = descriptionOfBook;
            this.price = price;
        }

        public override string ToString()
        {
            return $" BookId : {Id}; Books Name : {bookName}; Author Name : {authorName}; Book Description : {descriptionOfBook}; price:{price};";
        }
        public void editExistingBook(List<Books> blist,int bid)//non static method as static keyword is not used .we should call using object of the class
        {
           
            for (int i = 0; i < blist.Count; i++) {
                if (blist[i].Id == bid) {
                    Console.WriteLine("Enter the edited bookName:");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter the edited bookPrice:");
                  double prc = Convert.ToDouble(Console.ReadLine());
                    blist[i].bookName = name;
                    blist[i].price = prc;

                    Console.WriteLine("Book after editing: "+blist[i].ToString());
                }
            }          
           
        }
    }
    internal class Program
    {
        static void displayBook(List<Books> arr)
        {
            foreach (Books item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            List<Books> bookList = new List<Books>{

                new Books(101, "Ramayana","Valmikiramayana","Ramayanam", 300),
                new Books(102, "Mahabharatha","Vyasa","Mahabharatham", 300),
                new Books(103, "Saichalis","Mohan","Parayanam", 300),
                new Books(104, "Srikrishnadevaraya","Amukthamalyadha","Culture", 300),
                new Books(105, "Gowthambudda","Budda","Inspirer ", 300),

            };
            displayBook(bookList);
            Books bookObj = new Books();
           
            int num = 0;
            Console.WriteLine();
            bool iterate = true;
            while (iterate)
            {

                Console.WriteLine("Press 1 : Edit the Book ");
                Console.WriteLine("Press 2 : Delete the Book");
                Console.WriteLine("Press 3 : Add  the book ");
                Console.WriteLine("Press 4 : show discription");
                Console.WriteLine("press 5 : For Exit");

                Console.WriteLine("\nEnter the choice to do respective book operation");
                num = int.Parse(Console.ReadLine());

                switch (num)
                {
                    case 1:

                        //Console.WriteLine("Press 1 : Edit the Book name ");
                        //Console.WriteLine("Press 2 : Edit the Book author  ");
                        //Console.WriteLine("Press 3 : Edit the Book description  ");
                        //Console.WriteLine("Press 4 : Edit the Book price  ");

                        Console.WriteLine("enter the book id whose details you want to edit:");
                        int bid = Convert.ToInt32(Console.ReadLine());
                        bookObj.editExistingBook(bookList,bid);
                        break;


                        //Console.WriteLine("Enter number according to edit");
                        //int selectedNum = int.Parse(Console.ReadLine());

                         
                        
                           
                    case 2:

                        Console.WriteLine("Enter the Id of book You  want to delete");
                        int deleteId = int.Parse(Console.ReadLine());
                        int index = 0;
                        foreach (Books item in bookList)
                        {
                            if (item.Id == deleteId)
                            {
                                index = bookList.IndexOf(item);

                            }
                        }
                        bookList.RemoveAt(index);
                        displayBook(bookList);

                        break;
                    case 3:

                        Console.WriteLine("how many books You want to add");
                        int n = int.Parse(Console.ReadLine());

                        for (int i = 1; i <= n; i++)
                        {
                            Console.WriteLine("Enter the book  Details You  want to Add");
                            Console.WriteLine("Enter the name");
                            string bookName = Console.ReadLine();

                            Console.WriteLine("Enter the name");
                            string authorName = Console.ReadLine();

                            Console.WriteLine("Enter the name");
                            string descriptionOfBook = Console.ReadLine();

                            Console.WriteLine("Enter the Price");
                            float price;
                            bool result = Single.TryParse(Console.ReadLine(), out price);

                            if (result)
                            {
                                bookList.Add(new Books(bookList.Count + i, bookName, authorName, descriptionOfBook, price));

                            }
                        }
                        displayBook(bookList);
                        break;

                    case 4:

                        Console.WriteLine("showing description of book");
                        int showId = int.Parse(Console.ReadLine());
                        int index1 = 0;
                        foreach (Books item in bookList)
                        {
                            if (item.Id == showId)
                            {
                                index1 = bookList.IndexOf(item);

                            }
                        }
                        Console.WriteLine(bookList[index1].descriptionOfBook);
                        break;

                    case 5:


                        Console.WriteLine("showing display of book");
                        int showId1 = int.Parse(Console.ReadLine());
                        int index2 = 0;
                        foreach (Books item in bookList)
                        {
                            if (item.Id == showId1)
                            {
                                index2 = bookList.IndexOf(item);

                            }
                        }
                        Console.WriteLine(bookList[index2]);
                        break;
                }
            }//switch
            Console.ReadLine();
        }

    }

}
    

